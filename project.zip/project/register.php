<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Bootstrap Admin Theme</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	
	<style>
		body{
			background-color: #999999;
		}
	</style>
	
</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading" style="color:white;background-color:#337ab7">
                        <h1 class="panel-title" align=center>Philippine Airlines | Registration</h1>
                    </div>
                    <div class="panel-body">
                        <form action="index.html">
							<div class="col-lg-6 col-xs-12">
								<div class="input-group" style="margin-bottom:10px;">
									<div class="input-group-addon">
										<i class="fa fa-user"></i>
									</div>
									<input type="text" class="form-control" placeholder="First Name" autofocus required>
								</div>
							</div>
							<div class="col-lg-6 col-xs-12">
								<div class="input-group" style="margin-bottom:10px;">
									<div class="input-group-addon">
										<i class="fa fa-user"></i>
									</div>
									<input type="date" class="form-control" placeholder="Birth Date" min="01-01-1999" max="<?php echo date('Y-m-d');?>" required>
								</div>
							</div>
							<div class="col-lg-6 col-xs-12">
								<div class="input-group" style="margin-bottom:10px;">
									<div class="input-group-addon">
										<i class="fa fa-user"></i>
									</div>
									<input type="text" class="form-control" placeholder="Middle Name" required>
								</div>
							</div>
							<div class="col-lg-6 col-xs-12">
								<div class="input-group" style="margin-bottom:10px;">
									<div class="input-group-addon">
										<i class="fa fa-user"></i>
									</div>
									<input type="email" class="form-control" placeholder="Email" required>
								</div>
							</div>
							<div class="col-lg-6 col-xs-12">
								<div class="input-group" style="margin-bottom:10px;">
									<div class="input-group-addon">
										<i class="fa fa-user"></i>
									</div>
									<input type="text" class="form-control" placeholder="Last Name" required>
								</div>
							</div>
							<div class="col-lg-6 col-xs-12">
								<div class="input-group" style="margin-bottom:10px;">
									<div class="input-group-addon">
										<i class="fa fa-lock"></i>
									</div>
									<input type="password" class="form-control" placeholder="Password" required>
								</div>
							</div>
							<div class="col-lg-6 col-md-12">
								<input type='reset' value="Clear" class="btn btn-md btn-danger btn-block">
							</div>
							<div class="col-lg-6 col-md-6">
								<input type='submit' value="Register" class="btn btn-md btn-primary btn-block">
							</div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>

</body>

</html>
