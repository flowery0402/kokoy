<?php
	session_start();
	$username = $_POST['txtusername'];
	$password = $_POST['txtpassword'];
	
	$_SESSION['username']= $username;
	
	$conn = new mysqli("localhost","root","","testing");
	if($conn->connect_error)
	{	
		die("Can't connect to server");
	}
	
	$result = $conn->query("SELECT * from user WHERE username = '$username' and password = '$password'");
	
	if($result->num_rows>0){
		echo"
			<script>
				alert('Welcome Captain, $username!');
				location = 'http://localhost/project/index.php';
			</script>
		";
	}
	else{
		echo"
			<script>
				alert('Incorrect username or password! Try again.');
				location = 'http://localhost/project/login.html';
			</script>
		";
	}
?>