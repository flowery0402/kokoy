<?php
$fn=$_POST['txtfname'];
$ln=$_POST['txtlname'];
$mn=$_POST['txtmname'];
$bd=$_POST['bdate'];
$ad=$_POST['txtaddress'];
$un=$_POST['txtuname'];
$ps=$_POST['txtpassword'];
$pn=$_POST['txtnumber'];

$conn=new mysqli("localhost","root","","testing");

if($conn->connect_error)
{
	die("Error in connecting to server");
}	
else
{
	if($conn->query("INSERT INTO user(fname,lname,mname,bdate,address,username,password,phoneNO)values('$fn','$ln','$mn','$bd','$ad','$un','$ps','$pn')")=== true)
	{
		echo"
			<script>
				alert('You have successfully registered At BARANGAY INFORMATION FOR FLOOD');
				location = 'http://localhost/project/login.html';
			</script>
		";
	}
	else
	{
		echo"May mali bes";
		echo $conn->error;
	}
}	
?>