 <?php  
 $connect = mysqli_connect("localhost", "root", "", "testing");  
 if($_GET)  
 {  
      $output = '';  
      $message = '';  
      $name = $_GET["name"];  
      $name_of_barangay = $_GET["name_of_barangay"];  
      $no_of_population = $_GET["no_of_population"];  
      $level_of_water = $_GET["level_of_water"];  
      $evacuation_area = $_GET["evacuation_area"];  
      if($_GET["employee_id"] != '')  
      {  
           $query = "  
           UPDATE tbl_employee   
           SET name='$name',   
           name_of_barangay ='$name_of_barangay',   
           no_of_population ='$no_of_population',   
           level_of_water = '$level_of_water',   
           evacuation_area = '$evacuation_area'   
           WHERE id='".$_GET["employee_id"]."'";  
           $message = 'Data Updated';  
      }  
      else  
      {  
           $query = "INSERT INTO tbl_employee(name, name_of_barangay, no_of_population, level_of_water, evacuation_area) VALUES ('$name','$name_of_barangay', '$no_of_population', '$level_of_water', '$evacuation_area')";  
           $message = 'Data Inserted';  
      }  
      if(mysqli_query($connect, $query))  
      {  
           $output .= '<label class="text-success">' . $message . '</label>';  
           $select_query = "SELECT * FROM tbl_employee ORDER BY id DESC";  
           $result = mysqli_query($connect, $select_query);  
           $output .= '  
                <table class="table table-bordered">  
                     <tr>  
                          <th width="70%">Name</th>  
                          <th width="15%">Edit</th>  
                        
                          <th width="15%">Delete</th>
                     </tr>  
           ';  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr>  
                          <td>' . $row["name"] . '</td>  
                          <td><input type="button" name="edit" value="Edit" id="'.$row["id"] .'" class="btn btn-info btn-xs edit_data" /></td>  
                          
                          <td><input type="button" name="delete" value="delete" id="' . $row["id"] . '" class="btn btn-danger btn-xs delete_data" /></td>
                     </tr>
                     
                ';  
           }  
           $output .= '</table>';  
      } 
     else
     {
        $error = "Error Adding";
          $output .= '<label class="text-danger">' . $error . '</label>';  
           $select_query = "SELECT * FROM tbl_employee ORDER BY id DESC";  
           $result = mysqli_query($connect, $select_query);  
           $output .= '  
                <table class="table table-bordered">  
                     <tr>  
                          <th width="70%">Name</th>  
                          <th width="15%">Edit</th>  
                            
                          <th width="15%">Delete</th>
                     </tr>  
           ';  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr>  
                          <td>' . $row["name"] . '</td>  
                          <td><input type="button" name="edit" value="Edit" id="'.$row["id"] .'" class="btn btn-info btn-xs edit_data" /></td>  
                         
                          <td><input type="button" name="delete" value="delete" id="' . $row["id"] . '" class="btn btn-danger btn-xs delete_data" /></td>
                     </tr>  
                ';  
           }  
           $output .= '</table>';  
     }
      echo $output;  
 }  

 ?>
 