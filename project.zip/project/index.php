<?php  
 $connect = mysqli_connect("localhost", "root", "", "testing");  
 $query = "SELECT * FROM tbl_employee ORDER BY id DESC";  
 $result = mysqli_query($connect, $query);  
 ?>  
<!DOCTYPE html>  
 <html>  
      <head>  
           <title>Activity</title>
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			 <meta http-equiv="X-UA-Compatible" content="IE=edge">
           <link href="css/site.css" rel="stylesheet">
           <link href="css/bootstrap.min.css" rel="stylesheet">
           <script src="js/jquery-1.8.3.min.js"></script>
           <script src="js/bootstrap.min.js"></script>
           <link rel="stylesheet" href="style.css">	 
		<style>
		body{
			background-color: #85c2ff;
		}
		
	
	</style>   
      </head>  
      <body>  
           
			<nav id="center">
			<a href="login.html" class="btn btn-success btn-danger">
		    <span class="glyphicon glyphicon-log-out"></span> Log out
			</a>
                <ul class="list-unstyled CTAs">
				<h4 align="center">BARANGAY REGISTRATION FORM</h4>
					<button type="button" name="add" id="add" data-toggle="modal" data-target="#add_data_Modal" class="btn btn-primary btn-block">Add</button> 	
                </ul>
            </nav>
           <div class="container" style="width:700px;">  
                <h3 align="center"></h3>  
                <br />  
                <div class="table-responsive">  
                       
                     
                     <div id="Information_table">  
                          <table class="table table-striped table-bordered table-hover table-condensed">  
                               <tr> 
									<th width="70%">Name</th>
                                   <th width="15%">View</th>                               
                               </tr>  
                               <?php  
                               while($row = mysqli_fetch_array($result))  
                               {  
                               ?>  
                               <tr>  
                                    <td><?php echo $row["name"]; ?></td>  
									<td><input type="button" name="view" value="view" id="<?php echo $row["id"]; ?>" class="btn btn-primary btn-xs view_data" /></td>  
                               </tr>  
                               <?php  
                               }  
                               ?>  
                          </table>  
                     </div>  
                </div>  
           </div> 
      </body>  
 </html>  
 <div id="dataModal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                      
                     <h4 class="modal-title">DETAILS</h4>  
                </div>  
                <div class="modal-body" id="captain_detail">  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>  
           </div>  
      </div>  
 </div>  
 <div id="add_data_Modal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                    
                     <h4 class="modal-title">ADD INFORMATION</h4>  
                </div>  
                <div class="modal-body">  
                     <form method="post" id="insert_form" action="insert.php">  
                          <label>Name</label>  
                          <input type="text" name="name" id="name" class="form-control" />  
                          <br />  
                          <label>Name of Barangay</label>  
                          <textarea name="name_of_barangay" id="name_of_barangay" class="form-control"></textarea>  
                          <br />
						  <br />  
                          <label>No. of Population</label>  
                          <input type="text" name="no_of_population" id="no_of_population" class="form-control" />  
                          <br />
                          <label>Level of Water</label>  
                          <select name="level_of_water" id="level_of_water" class="form-control">  
                               <option value="1">1ft</option>  
                               <option value="2">2ft</option>
							   <option value="3">3ft</option> 
							   <option value="4">4ft</option>  
                          </select>  
                          <label>Evacuation Area</label>  
                          <input type="text" name="evacuation_area" id="evacuation_area" class="form-control" />  
                          <br />  
                          <input type="hidden" name="employee_id" id="employee_id" />  
                          <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-success" />
						
                     </form>  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div>  
 <script>  
 $(document).ready(function(){  
      $('#add').click(function(){  
           $('#insert').val("Insert");  
           $('#insert_form')[0].reset();  
      });  
      $(document).on('click', '.edit_data', function(){  
           var employee_id = $(this).attr("id");  
           $.ajax({  
                url:"fetch.php",  
                method:"POST",  
                data:{employee_id:employee_id},  
                dataType:"json",  
                success:function(data){  
                     $('#name').val(data.name);  
                     $('#name_of_barangay').val(data.name_of_barangay);  
                     $('#no_of_population').val(data.no_of_population);  
                     $('#level_of_water').val(data.level_of_water);  
                     $('#evacuation_area').val(data.evacuation_area);  
                     $('#employee_id').val(data.id);  
                     $('#insert').val("Update");  
                     $('#add_data_Modal').modal('show');  
                }  
           });  
      });  
      $('#insert_form').on("submit", function(event){  
           event.preventDefault();  
          var form = $(this);
           if($('#name').val() == "")  
           {  
                alert("Name is required");  
           }  
           else if($('#name_of_barangay').val() == '')  
           {  
                alert("Name of barangay is required");  
           }  
           else if($('#no_of_population').val() == '')  
           {  
                alert("No.of population is required");  
           }  
		   else if($('#level_of_water').val() == '')  
           {  
                alert("Level of water is required");  
           } 
           else if($('#evacuation_area').val() == '')  
           {  
                alert("Evacuation area is required");  
           }  
           else 
           {  
                $.ajax({  
                     url:form.attr('action'),  
                     method:form.attr('method'),  
                     data:form.serialize(),  
                     success:function(data){  
                          $('#insert_form')[0].reset();  
                          $('#add_data_Modal').modal('hide');  
                          $('#Information_table').html(data);  
                     }  
                });  
           }  
      });  
      $(document).on('click', '.view_data', function(){  
           var employee_id = $(this).attr("id");  
           if(employee_id != '')  
           {  
                $.ajax({  
                     url:"select.php",  
                     method:"POST",  
                     data:{employee_id:employee_id},  
                     success:function(data){  
                          $('#captain_detail').html(data);  
                          $('#dataModal').modal('show');  
                     }  
                });  
           }            
      }); 
    $(document).on('click', '.delete_data', function(){
         var employee_id = $(this).attr('id');
         if(employee_id != '')
         {
             $.ajax({
                   url:"delete.php",  
                    method:"POST",  
                    data:{employee_id:employee_id}, 
                success:function(data){
            $('#Information_table').html(data);
             }
                 
             });
         }
         
     });

 });  
 </script>