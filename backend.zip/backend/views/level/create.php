<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\Level */

$this->title = 'Add Level';
$this->params['breadcrumbs'][] = ['label' => 'Levels', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="level-create">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
