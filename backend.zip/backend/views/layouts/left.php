<?php
    use yii\helpers\Html;
    use yii\helpers\Url;
?>
<aside class="main-sidebar">

    <section class="sidebar">

        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
             <!--    <img src= class="img-circle" alt="User Image"/> -->
             <?= Html::img(Url::to('@web/logo.png'), ['class'=>'img-circle']) ?>
            </div>
            <div class="pull-left info">
                <p><?= Yii::$app->user->identity->username ?></p>

                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>

        <?= dmstr\widgets\Menu::widget(
            [
                'options' => ['class' => 'sidebar-menu tree', 'data-widget'=> 'tree'],
                'items' => [
                    ['label' => 'Manage', 'options' => ['class' => 'header']],
                    ['label' => 'Users', 'icon' => 'user', 'url' => ['/user/admin']],
                    ['label' => 'Roles', 'icon' => 'navicon ', 'url' => ['/role-list']],
                    ['label' => 'Roles Description', 'icon' => 'folder', 'url' => ['/roles']],
                    ['label' => 'Bulletin', 'icon' => 'edit (', 'url' => ['/bulletin']],
                    ['label' => 'Levels', 'icon' => 'external-link-square', 'url' => ['/level']],
                    ['label' => 'Emergency Hotlines', 'icon' => 'location-arrow', 'url' => ['/contact']],
                ],
            ]
        ) ?>

    </section>

</aside>
