<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/**
 * @var yii\web\View              $this
 * @var yii\widgets\ActiveForm    $form
 * @var dektrium\user\models\User $user
 */

$this->title = Yii::t('user', 'Sign up');
$this->params['breadcrumbs'][] = $this->title;
?>
<style type="text/css">
    .registration {
        padding-top: 120px;
    }
    body {
        background-color: #bfbfbf;
    }
</style>
<div class="container registration">
    <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8 registration-box">
            <div class="login-logo">
                <a href="#"><b>Flood Control</b> System</a>
            </div>        
            <div class="box box-primary">
              <div class="box-header with-border">
                <h3 class="box-title">Registration for Administrator</h3>
                <span class="label label-primary pull-right"><i class="fa fa-html5"></i></span>
              </div><!-- /.box-header -->
              <div class="box-body">
                <?php $form = ActiveForm::begin([
                    'id' => 'registration-form',
                ]); ?>

                <?= $form->field($model, 'username') ?>

                <?= $form->field($model, 'email') ?>

                <?= $form->field($model, 'password')->passwordInput() ?>

                <div class="pull-right">
                    <?= Html::submitButton(Yii::t('user', 'Sign up'), ['class' => 'btn btn-success btn-md']) ?>
                </div>
                <?php ActiveForm::end(); ?>
              </div><!-- /.box-body -->
              <div class="box-footer">
                <center><?= Html::a(Yii::t('user', 'Already registered? Sign in!'), ['/user/security/login']) ?></center>
              </div>              
            </div>        
        </div>
        <div class="col-sm-2"></div>
    </div>
</div>