<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\RoleList */

$this->title = 'Create Role List';
$this->params['breadcrumbs'][] = ['label' => 'Role Lists', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="role-list-create">

    <?= $this->render('_form', [
        'model' => $model,
        'users' => $users,
        'roles' => $roles
    ]) ?>

</div>
