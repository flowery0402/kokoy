<?php

/* @var $this yii\web\View */

$this->title = 'Dashboard';
?>
<div class="site-index">

    <div class="jumbotron">
        <h3>Welcome to Flood Control System</h3>
    </div>

    <div class="body-content">

 
    </div>
</div>
