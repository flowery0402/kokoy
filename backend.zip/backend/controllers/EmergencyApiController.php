<?php

namespace backend\controllers;

use yii\rest\ActiveController;
use yii\filters\ContentNegotiator;
use yii\web\Response;
use yii\filters\AccessControl;
use yii\filters\auth\HttpBearerAuth;
use yii\filters\VerbFilter;
use yii\data\ActiveDataProvider;
use frontend\models\Flood;
use backend\models\Level;

class EmergencyApiController extends ActiveController
{   
    public $modelClass = 'backend\models\Contact';

}

