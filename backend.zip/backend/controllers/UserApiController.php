<?php

namespace backend\controllers;

use yii\rest\ActiveController;


class UserApiController extends ActiveController
{   
    public $modelClass = 'frontend\models\Flood';

}

