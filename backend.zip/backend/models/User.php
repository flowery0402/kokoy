<?php
namespace backend\models;

use dektrium\user\models\User as BaseUser;

class User extends BaseUser
{

}