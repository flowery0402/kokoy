<?php

/*
 * This file is part of the Dektrium project.
 *
 * (c) Dektrium project <http://github.com/dektrium/>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace backend\models;

use dektrium\user\traits\ModuleTrait;
use Yii;
use yii\base\Model;

/**
 * Registration form collects user input on registration process, validates it and creates new User model.
 *
 * @author Dmitry Erofeev <dmeroff@gmail.com>
 */
class Profile extends \dektrium\user\models\Profile
{
    /**
     * @var string
     */
    // public $bdate;
    /**
     * @inheritdoc
     */
    public function rules()
    {
        $rules = parent::rules();
        // $rules['fieldRequired'] = ['bdate', 'required'];
        $rules['fieldRequired'] = ['bdate', 'datetime', 'format' => 'php:Y-m-d'];
        return $rules;
    }
}
