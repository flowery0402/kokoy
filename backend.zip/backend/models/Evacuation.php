<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "{{%evacuation}}".
 *
 * @property int $id
 * @property string $location
 */
class Evacuation extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return '{{%evacuation}}';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['location'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'location' => 'Location',
        ];
    }
}
