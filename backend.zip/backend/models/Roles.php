<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "{{%roles}}".
 *
 * @property int $id
 * @property string $role_desc
 *
 * @property RoleList[] $roleLists
 */
class Roles extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return '{{%roles}}';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['role_desc'], 'string', 'max' => 50],
            ['role_desc', 'required'],

        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'role_desc' => 'Role Description',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRoleLists()
    {
        return $this->hasMany(RoleList::className(), ['role_id' => 'id']);
    }
}
