<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "{{%bulletin}}".
 *
 * @property int $id
 * @property string $description
 * @property int $created_at
 * @property string $subject
 */
class Bulletin extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return '{{%bulletin}}';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['description'], 'string'],
            [['subject'], 'string', 'max' => 155],
            [['description', 'subject', 'created_at'], 'required'],
         
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'description' => 'Description',
            'created_at' => 'Created At',
            'subject' => 'Subject',
        ];
    }
}
