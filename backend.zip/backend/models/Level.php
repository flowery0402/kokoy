<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "{{%level}}".
 *
 * @property int $id
 * @property string $level_desc
 * @property string $color
 * @property double $radius
 *
 * @property Flood[] $floods
 */
class Level extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return '{{%level}}';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['radius'], 'number'],
            [['level_desc'], 'string', 'max' => 255],
            [['color'], 'string', 'max' => 55],
            [['radius', 'level_desc', 'color'], 'required']
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'level_desc' => 'Level',
            'color' => 'Color',
            'radius' => 'Radius',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFloods()
    {
        return $this->hasMany(Flood::className(), ['level' => 'id']);
    }
}
