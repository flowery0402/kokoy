 <?php  
 if(isset($_GET["employee_id"]))  
 {  
      $output = '';  
      $connect = mysqli_connect("localhost", "root", "", "testing");  
      $query = "SELECT * FROM tbl_employee WHERE id = '".$_GET["employee_id"]."'";  
      $result = mysqli_query($connect, $query);  
      $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td width="30%"><label>Name</label></td>  
                     <td width="70%">'.$row["name"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Name of barangay</label></td>  
                     <td width="70%">'.$row["name_of_barangay"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>No. of population</label></td>  
                     <td width="70%">'.$row["no_of_population"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Level of water</label></td>  
                     <td width="70%">'.$row["level_of_water"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Evacuation area</label></td>  
                     <td width="70%">'.$row["evacuation_area"].'</td>  
                </tr>  
                </table>  
            <div align="right"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button> 
            <input type="button" name="edit" value="update" id="'.$row["id"].'" class="btn btn-info btn-xs edit_data" />
            <input type="button" name="delete" value="delete" id="'.$row["id"].'" class="btn btn-danger btn-xs delete_data" /></div> 
                
           ';  
      }  
      $output .= '  
           
      </div>  
      ';  
      echo $output;  
 }  
else 
    echo "asdasd"; 
 ?>
 