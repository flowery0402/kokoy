 <?php  
 $connect = mysqli_connect("localhost", "root", "", "testing");  
 if($_GET)  
 {  
      $output = '';  
      $message = '';  
      $name = $_GET["name"];  
      $name_of_barangay = $_GET["name_of_barangay"];  
      $no_of_population = $_GET["no_of_population"];  
      $level_of_water = $_GET["level_of_water"];  
      $evacuation_area = $_GET["evacuation_area"];  
      if($_GET["employee_id"] != '')  
      {  
           $query = "  
           UPDATE tbl_employee   
           SET name='$name',   
           name_of_barangay ='$name_of_barangay',   
           no_of_population ='$no_of_population',   
           level_of_water = '$level_of_water',   
           evacuation_area = '$evacuation_area'   
           WHERE id='".$_GET["employee_id"]."'";  
           $message = 'Data Updated';  
      }  
      else  
      {  
           $query = "INSERT INTO tbl_employee(name, name_of_barangay, no_of_population, level_of_water, evacuation_area) VALUES ('$name','$name_of_barangay', '$no_of_population', '$level_of_water', '$evacuation_area')";  
           $message = 'Data Inserted';  
      }  
      if(mysqli_query($connect, $query))  
      {  
        
      } 
     else
     {
         
     }
     
 }  

 ?>
 