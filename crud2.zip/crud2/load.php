<?php
$output = '';  
$output .= ' 
                <h3 align="center">SUB ADMINISTRATOR</h3>  
                <br />  

     <div align="right" class="addpage">  
                          <button type="button" name="add" id="add" class="btn btn-warning ">Add</button>  
                     </div> 
    <br><br>
	
	<table class="table table-bordered table-condensed table-hover " cellspacing="0" width="100%">
        <thead>
            <tr align="center">
            	<th width="70%" >Name</th>  

            </tr>
        </thead>
        
        <tbody>
            
            ';
			
			$connect = mysqli_connect("localhost", "root", "", "testing"); 
            $query = "SELECT * FROM tbl_employee ";  
            $result = mysqli_query($connect, $query);
            
			if(mysqli_num_rows($result)>0){
                  while($row = mysqli_fetch_array($result)){ 
            $output .= ' 
           
                    <tr>  
             
                       <td width="70%" class="clickme" id="'.$row["id"].'">'.$row["name"].'</td>  
                    </tr>  
           ';
        } 
            }	
            else {
				
				$output .= ' 
		        <tr>
		        <td colspan="3">No People Found</td>
		        </tr>
		        ';
				
			}
			
				$output .= '
             
        </tbody>
    </table>
    ';
echo $output;
?>