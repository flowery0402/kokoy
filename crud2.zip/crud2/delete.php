 <?php  
 $connect = mysqli_connect("localhost", "root", "", "testing");  

if($_GET){
    $output = '';  
    $message = ''; 
    $id = $_GET["employee_id"];
    
    
    $query = "DELETE FROM tbl_employee WHERE id = '$id'";
    
    $result = mysqli_query($connect,$query);
    if($result){
    }
       
}  



 ?>
 